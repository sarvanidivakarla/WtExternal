<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f3f4f6; }
        form { width: 340px; margin: 50px auto; padding: 20px; background: white; border: 1px solid #d1d5db; }
        input, button { width: 100%; box-sizing: border-box; padding: 9px; margin: 8px 0; }
        button { background: #2563eb; color: white; border: 0; }
        .error { color: red; }
    </style>
</head>
<body>
    <form action="login" method="post">
        <h2>Book Store Login</h2>
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <button type="submit">Login</button>
        <p class="error">${error}</p>
    </form>
</body>
</html>
