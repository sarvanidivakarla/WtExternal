<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>body { font-family: Arial, sans-serif; margin: 28px; }</style>
</head>
<body>
    <h1>Welcome, <%= user %></h1>
    <p>This page is restricted to authenticated users.</p>
    <h2>Member Books</h2>
    <ul>
        <li>Core Java</li>
        <li>Web Technologies</li>
        <li>Database Systems</li>
    </ul>
    <form action="logout" method="post">
        <button type="submit">Logout</button>
    </form>
</body>
</html>
