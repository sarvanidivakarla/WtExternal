# Week 9 - User Authentication Using Servlet and JSP

## Aim

Implement user authentication using servlets and JSP. Create a login page and restrict access to certain pages for authenticated users.

## Files Used

- `pom.xml` - Maven web project setup
- `src/main/webapp/login.jsp` - login page
- `src/main/webapp/dashboard.jsp` - protected page
- `src/main/java/com/bookstore/LoginServlet.java` - validates username and password
- `src/main/java/com/bookstore/LogoutServlet.java` - clears session and logs out user

## Concepts Involved

### Authentication

Authentication is the process of checking whether a user is valid. It usually verifies username and password.

In this lab:

- Username: `student`
- Password: `password123`

### Authorization

Authorization checks what an authenticated user is allowed to access. In this lab, only logged-in users can access `dashboard.jsp`.

### JSP

JSP stands for Java Server Pages. It is used to create dynamic web pages using HTML with Java support.

In this lab:

- `login.jsp` displays login form
- `dashboard.jsp` displays protected content

### Servlet

The servlet receives login form data, checks credentials and redirects or forwards the user.

### Session

A session stores user data across multiple requests. HTTP is stateless, so session helps remember that the user has logged in.

In this lab:

```java
request.getSession().setAttribute("user", username);
```

stores the logged-in username in the session.

### Request Dispatching

`RequestDispatcher` forwards the request from servlet to JSP without asking the browser to make a new request.

Used when login fails:

```java
request.getRequestDispatcher("login.jsp").forward(request, response);
```

### Redirect

Redirect tells the browser to open another URL.

Used when login succeeds:

```java
response.sendRedirect("dashboard.jsp");
```

### Logout

Logout is done by invalidating the session:

```java
request.getSession().invalidate();
```

This removes stored session data.

## Setup Steps

### Required Software

- Java JDK 8 or 11
- Maven
- Apache Tomcat 9
- Eclipse or IntelliJ IDEA

### Run in Eclipse

1. Import `Week-09-Authentication-Servlet-JSP` as an existing Maven project.
2. Wait until dependencies are downloaded.
3. Right-click project and select `Run As > Run on Server`.
4. Choose Tomcat 9.
5. Open:

```text
http://localhost:8080/Week-09-Authentication-Servlet-JSP/login.jsp
```

6. Try invalid credentials first.
7. Then login using:

```text
Username: student
Password: password123
```

8. After login, `dashboard.jsp` should open.
9. Click logout to end the session.

## Expected Output

- Invalid login shows error message.
- Valid login opens dashboard.
- Dashboard is restricted if user is not logged in.
- Logout clears the session and returns to login page.

## Viva Questions and Answers

### What is authentication?

Authentication verifies the identity of a user.

### What is authorization?

Authorization decides what resources a logged-in user can access.

### What is JSP?

JSP is a server-side technology used to create dynamic web pages.

### What is a session?

A session stores user-specific data on the server across multiple requests.

### Why is session needed?

HTTP is stateless, so the server needs session tracking to remember logged-in users.

### What is the difference between forward and redirect?

Forward happens on the server side without changing the browser URL. Redirect asks the browser to make a new request and changes the URL.

### What is `sendRedirect()`?

It sends a redirect response to the browser.

### What is `RequestDispatcher`?

It forwards a request to another server-side resource such as JSP.

### What does `session.invalidate()` do?

It destroys the session and removes stored session attributes.

### Why should passwords not be hardcoded in real projects?

Hardcoded passwords are insecure. Real projects store hashed passwords in a database.

## From Blank System Using VS Code

Required software:

- Visual Studio Code
- Java JDK 8 or 11
- Maven
- Apache Tomcat 9
- Extension Pack for Java
- Maven for Java
- Community Server Connectors or Tomcat server extension

Create this structure:

```text
Week-09-Authentication-Servlet-JSP/
  pom.xml
  src/main/java/com/bookstore/LoginServlet.java
  src/main/java/com/bookstore/LogoutServlet.java
  src/main/webapp/login.jsp
  src/main/webapp/dashboard.jsp
```

Steps:

1. Create the folder and open it in VS Code.
2. Create `pom.xml` with WAR packaging and `javax.servlet-api`.
3. Create servlet files under `src/main/java/com/bookstore`.
4. Create JSP files under `src/main/webapp`.
5. In `LoginServlet`, read username and password from request parameters.
6. Store valid user in session.
7. Redirect valid users to `dashboard.jsp`.
8. Forward invalid users back to `login.jsp`.
9. In `dashboard.jsp`, check the session before showing content.
10. Run `mvn clean package`.
11. Deploy the WAR to Tomcat and open `login.jsp` through Tomcat.
