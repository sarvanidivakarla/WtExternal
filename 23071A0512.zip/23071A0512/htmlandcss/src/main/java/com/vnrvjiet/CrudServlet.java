package com.vnrvjiet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class CrudServlet extends HttpServlet {
    private StudentDataStore dataStore = StudentDataStore.getInstance();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action) || action == null) {
            addStudent(request, response);
        } else if ("update".equals(action)) {
            updateStudent(request, response);
        } else if ("delete".equals(action)) {
            deleteStudent(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("edit".equals(action)) {
            editStudent(request, response);
        } else if ("delete".equals(action)) {
            deleteStudent(request, response);
        }
    }

    private void addStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String roll = request.getParameter("roll");
        String email = request.getParameter("email");
        String address = request.getParameter("address");

        Student student = new Student();
        student.setName(name);
        student.setRoll(roll);
        student.setEmail(email);
        student.setAddress(address);

        dataStore.addStudent(student);
        response.sendRedirect("index.jsp");
    }

    private void editStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Student student = dataStore.getStudentById(id);

        request.setAttribute("student", student);
        RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
        dispatcher.forward(request, response);
    }

    private void updateStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String roll = request.getParameter("roll");
        String email = request.getParameter("email");
        String address = request.getParameter("address");

        Student student = new Student(id, name, roll, email, address);
        dataStore.updateStudent(student);
        response.sendRedirect("index.jsp");
    }

    private void deleteStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        dataStore.deleteStudent(id);
        response.sendRedirect("index.jsp");
    }
}
