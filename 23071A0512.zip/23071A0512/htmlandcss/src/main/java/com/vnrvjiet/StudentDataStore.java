package com.vnrvjiet;

import java.util.*;

public class StudentDataStore {
    private static StudentDataStore instance;
    private Map<Integer, Student> students;
    private int nextId;

    private StudentDataStore() {
        this.students = new LinkedHashMap<>();
        this.nextId = 1;
    }

    public static synchronized StudentDataStore getInstance() {
        if (instance == null) {
            instance = new StudentDataStore();
        }
        return instance;
    }

    // Create
    public Student addStudent(Student student) {
        student.setId(nextId++);
        students.put(student.getId(), student);
        return student;
    }

    // Read All
    public List<Student> getAllStudents() {
        return new ArrayList<>(students.values());
    }

    // Read by ID
    public Student getStudentById(int id) {
        return students.get(id);
    }

    // Update
    public Student updateStudent(Student student) {
        if (students.containsKey(student.getId())) {
            students.put(student.getId(), student);
            return student;
        }
        return null;
    }

    // Delete
    public boolean deleteStudent(int id) {
        return students.remove(id) != null;
    }

    // Get total count
    public int getTotalCount() {
        return students.size();
    }
}
