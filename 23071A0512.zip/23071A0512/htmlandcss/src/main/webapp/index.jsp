<%@ page import="java.util.List" %>
<%@ page import="com.vnrvjiet.Student" %>
<%@ page import="com.vnrvjiet.StudentDataStore" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student CRUD - VNRVJIET</title>
    <link rel="stylesheet" href="./style.css">
    <style>
        .crud-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-top: 20px;
        }
        .form-section, .table-section {
            background: rgba(248, 250, 255, 0.96);
            padding: 28px;
            border-radius: 24px;
            border: 1px solid rgba(102, 126, 234, 0.16);
            box-shadow: 0 18px 40px rgba(102, 126, 234, 0.08);
        }
        .table-section {
            grid-column: 1 / -1;
        }
        .form-section h3, .table-section h3 {
            color: #4a5ad9;
            margin-bottom: 20px;
            font-size: 1.5rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            border: 1px solid rgba(102, 126, 234, 0.2);
            padding: 12px;
            text-align: left;
        }
        table th {
            background: rgba(102, 126, 234, 0.1);
            font-weight: 600;
            color: #4a5ad9;
        }
        table tr:hover {
            background: rgba(102, 126, 234, 0.05);
        }
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        .btn-edit, .btn-delete, .btn-reset {
            padding: 8px 14px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        .btn-edit {
            background: #4a5ad9;
            color: white;
        }
        .btn-edit:hover {
            background: #3a49c9;
            transform: translateY(-2px);
        }
        .btn-delete {
            background: #e74c3c;
            color: white;
        }
        .btn-delete:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }
        .btn-reset {
            background: #95a5a6;
            color: white;
            width: 100%;
            margin-top: 10px;
        }
        .btn-reset:hover {
            background: #7f8c8d;
        }
        .form-section form button {
            width: 100%;
        }
        .no-records {
            text-align: center;
            color: #7f8c8d;
            padding: 40px 20px;
            font-size: 1.1rem;
        }
        .edit-mode {
            background: rgba(255, 235, 205, 0.6);
        }
        @media (max-width: 1024px) {
            .crud-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header>
        <img src="./download.png" alt="" srcset="">
        <h1>VNRVJIET- Student Management System</h1>
        <nav>
            <a href="#home">Home</a>
            <a href="#academics">Academics</a>
            <a href="#placement">Placement Docs</a>
            <a href="#contact">Contact Us</a>
        </nav>
    </header>
    <main>
        <h2>Student CRUD Operations</h2>
        <p>Manage student records with complete CRUD functionality.</p>
        
        <div class="crud-container">
            <!-- Form Section -->
            <div class="form-section <%= request.getAttribute("student") != null ? "edit-mode" : "" %>">
                <h3><%= request.getAttribute("student") != null ? "Edit Student" : "Add Student" %></h3>
                <form action="crud" method="post">
                    <%
                        Student student = (Student) request.getAttribute("student");
                        if (student != null) {
                    %>
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="id" value="<%= student.getId() %>">
                    <%
                        } else {
                    %>
                        <input type="hidden" name="action" value="add">
                    <%
                        }
                    %>
                    
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<%= student != null ? student.getName() : "" %>" required>
                    
                    <label for="roll">Roll Number:</label>
                    <input type="text" id="roll" name="roll" value="<%= student != null ? student.getRoll() : "" %>" required>
                    
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<%= student != null ? student.getEmail() : "" %>" required>
                    
                    <label for="address">Address:</label>
                    <textarea id="address" name="address" required><%= student != null ? student.getAddress() : "" %></textarea>
                    
                    <button type="submit"><%= student != null ? "Update Student" : "Add Student" %></button>
                </form>
                <% if (student != null) { %>
                    <form action="index.jsp" method="get" style="margin-top: 10px;">
                        <button type="submit" class="btn-reset">Cancel Edit</button>
                    </form>
                <% } %>
            </div>

            <!-- Table Section -->
            <div class="table-section">
                <h3>Student Records</h3>
                <%
                    StudentDataStore dataStore = StudentDataStore.getInstance();
                    List<Student> students = dataStore.getAllStudents();
                %>
                
                <% if (students.isEmpty()) { %>
                    <div class="no-records">
                        <p>No student records found. Add a new student to get started!</p>
                    </div>
                <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Roll Number</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for (Student s : students) { %>
                                <tr>
                                    <td><%= s.getId() %></td>
                                    <td><%= s.getName() %></td>
                                    <td><%= s.getRoll() %></td>
                                    <td><%= s.getEmail() %></td>
                                    <td><%= s.getAddress() %></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="crud?action=edit&id=<%= s.getId() %>" class="btn-edit">Edit</a>
                                            <a href="crud?action=delete&id=<%= s.getId() %>" class="btn-delete" onclick="return confirm('Are you sure?');">Delete</a>
                                        </div>
                                    </td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                    <p style="margin-top: 15px; color: #7f8c8d;"><strong>Total Records:</strong> <%= students.size() %></p>
                <% } %>
            </div>
        </div>
    </main>
    <footer>
        <h2>VNRVJIET- Footer Section</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas, voluptate.</p>
    </footer>
</body>
</html>
